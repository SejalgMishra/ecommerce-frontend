export const TYPES = {
  AUTH: "AUTH",
  DATA: "DATA",
  USER :"USER"
};

export const login = (Data: any) => {
  return {
    type: "AUTH",
    payload: Data,
  };
};

export const register = (Data: any) => {
  return {
    type: "DATA",
    payload: Data,
  };
};

export const user = (Data: any) => {
  return {
    type: "USER",
    payload: Data,
  };
};

