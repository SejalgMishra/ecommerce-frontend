import React from "react";
import Glasses from "../assets/image/glasses.jpg";
import Footware from "../assets/image/girlShoes.jpg";
import Shoe from "../assets/image/shoes.jpg";
import Bag from "../assets/image/purse.jpg";

const Products = () => {
  const Product = [
    {
      imgaes: Glasses,
      productName: "Comfort Eyewear",
      productCategory: "Unisex Eyewear",
      price: "$ 209.00 USD",
      oldPrice: "$ 709.00 USD",
    },
    {
      imgaes: Bag,
      productName: "Wizbee Rose Gold",
      productCategory: "Lady's Bag",
      price: "$ 20.00 USD",
      oldPrice: "$ 70.00 USD",
    },
    {
      imgaes: Shoe,
      productName: "Classic shoes",
      productCategory: "men 's shoes",
      price: "$ 209.00 USD",
      oldPrice: "$ 709.00 USD",
    },
    {
      imgaes: Footware,
      productName: "Vivio Brown ",
      productCategory: "Woemn's shoe",
      price: "$ 49.00 USD",
      oldPrice: "$ 89.00 USD",
    },
  ];
  return (
    <div className="flex-wrap">
      <h1 className="text-3xl   font-bold py-6 font-logo">New Arrivals</h1>
      <div className="flex flex-row justify-between flex-wrap h-[399px] md:h-auto overflow-hidden">
        {Product.map((x, index) => (
          <div key={index} className="flex flex-col ">
            <img
              src={x.imgaes}
              alt={x.productName}
              className="aspect-auto   h-[315px] w-[315px] object-cover"
            />
            <h2 className="font-sans text-xl mb-1">{x.productName}</h2>
            <h3 className="font-font mb-1">{x.productCategory}</h3>
            <div className="flex gap-2">
              <p className="font-base">{x.price}</p>
              <p className="line-through opacity-70">{x.oldPrice}</p>
            </div>
            <button className="btn-white">Add to cart</button>

          </div>
        ))}
      </div>
      <div className="flex justify-center py-14">
        <button className="btn">Shop All</button>
      </div>
    </div>
  );
};

export default Products;
