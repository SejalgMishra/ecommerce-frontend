export const TYPES = {
  LOAD_CART_REQUEST: "LOAD_CART_REQUEST",
  ADD_CART_REQUEST: "ADD_CART_REQUEST",
  UPDATE_CART_REQUEST: "UPDATE_CART_REQUEST",
  DELETE_CART_REQUEST: "DELETE_CART_REQUEST",
};

export const addToCart = (Data : any) => {
    return {
      type: "ADD_CART_REQUEST",
      payload : Data,
    };
  };