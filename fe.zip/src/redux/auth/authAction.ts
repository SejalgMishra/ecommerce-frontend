import { Dispatch } from "react";
import { RootState } from "..";

// Action Types
export const AUTH_REQUEST = "AUTH_REQUEST";
export const AUTH_SUCCESS = "AUTH_SUCCESS";
export const AUTH_FAILURE = "AUTH_FAILURE";

// Action Creators
export const authRequest = () => ({
  type: AUTH_REQUEST,
});

export const authSuccess = (user: User) => ({
  type: AUTH_SUCCESS,
  payload: user,
});

export const authFailure = (error: string) => ({
  type: AUTH_FAILURE,
  payload: error,
});

// Async Actions
export const authenticate = (email: string, password: string) => {
  return async (dispatch: Dispatch<any>, getState: () => RootState) => {
    dispatch(authRequest());

    // Simulating an async API call
    setTimeout(() => {
      // Check if authentication is successful (replace this with your actual authentication logic)
      
        // Registration logic
        const user = { email };
        dispatch(authSuccess(user));
   
        // Login logic
        if (email === "example@example.com" && password === "password") {
          const user = { email: "example@example.com" };
          dispatch(authSuccess(user));
        } else {
          const error = "Invalid email or password";
          dispatch(authFailure(error));
        
      }
    }, 2000);
  };
};
