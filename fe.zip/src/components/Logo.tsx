import React from "react";
import "../styles/logo.css";

const Logo = () => {
  return (
    <div className="logo">
      <h1 className="logotext">Xyla</h1><span className="logospan">.com</span>
    </div>
  );
};

export default Logo;
