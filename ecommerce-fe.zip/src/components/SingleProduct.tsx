import React from 'react'
import { useQuery } from 'react-query';
import { useSelector } from 'react-redux';

interface props {
    setOpen: (value: boolean) => void;
  }

const SingleProduct = ({setOpen} : props) => {
    const singleProduct = useSelector((state) => state.product.products);
    console.log(singleProduct);

    
    

  return (
    <div className="edit_profile fixed top-0 left-0 h-screen z-40 overflow-auto w-full bg-[#0008] ">
          <button
            className="btn  absolute top-4 right-4"
            onClick={() =>setOpen(false)}
          >
            Close
          </button>

          </div>
  )
}

export default SingleProduct