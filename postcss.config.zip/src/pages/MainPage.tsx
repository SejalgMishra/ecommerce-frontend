import React from 'react'
import Home from '../components/home'

const MainPage = () => {
  return (
    <div>
        <Home />
        
    </div>
  )
}

export default MainPage