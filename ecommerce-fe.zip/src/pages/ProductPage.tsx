import React from 'react'
;
import AllProduct from '../components/AllProduct';
import SideBar from '../components/sideBar';

const ProductPage = () => {
    return (
        <div>
            <AllProduct />
        </div>
    )
}

export default ProductPage