import { Form, Formik } from "formik";
import React from "react";
import abc from "../assets/image/login.jpg";

interface MyFormValues {
    username : string;
  email: string;
  password: string;
  confirm_password: string;

}

interface props {
    setIsLogin: (value: boolean) => void;
    setOpen: (value: boolean) => void;

}

const Register = ({setIsLogin , setOpen} : props) => {
  const initialValues: MyFormValues = { email: "", password: "" , confirm_password : "" , username : "" };

  return (
    <div>
      <Formik
        initialValues={initialValues}
        validate={(initialValues) => {
          const errors: Partial<MyFormValues> = {};

          if (!initialValues.username) {
            errors.username = "username is required";
          }
          

          if (!initialValues.email) {
            errors.email = "Email is required";
          }

          if (!initialValues.password) {
            errors.password = "Password is required";
          }
          if (!initialValues.confirm_password) {
            errors.confirm_password = "confirm password is required";
          }

          return errors;
        }}
      >
        {({ values, handleChange, handleSubmit, errors }) => (
          <Form
            onSubmit={handleSubmit}
            onChange={handleChange}
            className="max-w-screen-lg  mx-auto   mt-36  h-[70%] text-white flex "
          >
            <img src={abc} className="w-[50%] rounded-l-xl" />
            <div className="flex flex-col items-center  w-[50%] justify-center px-3 bg-black opacity-90 rounded-r-xl py-40">
              <h1 className="text-2xl font-bold mb-4">Register Page</h1>
              <div className="flex flex-col gap-1 w-full">
              <label>Username:</label>
              <input
                name="username"
                value={values.username}
                onChange={handleChange}
                placeholder="Your username"
                className="p-2 border-2 w-full  rounded-lg mb-2"
                type="text"
              />
             </div>
             <div className="flex flex-col gap-1 w-full">
              <label>Email:</label>
              <input
                name="email"
                value={values.email}
                onChange={handleChange}
                placeholder="Your Email"
                className="p-2 border-2 w-full  rounded-lg mb-2"
                type="email"
              />
              </div>

              <div className="flex flex-col gap-1 w-full">
              <label>Password:</label>
              <input
                name="password"
                value={values.password}
                onChange={handleChange}
                placeholder="Your password"
                className="p-2 border-2 w-full rounded-lg mb-2"
                type="password"
              />
              </div>
              <div className="flex flex-col gap-1 w-full">
              <label>Confirm Password:</label>
              <input
                name="email"
                value={values.confirm_password}
                onChange={handleChange}
                placeholder="Confirm Your Password"
                className="p-2 border-2 w-full  rounded-lg mb-2"
                type="password"
              />
              </div>
              <button
                type="submit"
                className="p-2 border-2 w-full border-gray-700  rounded-lg text-white"
                onClick={() => setOpen(false)}
              >
                Submit
              </button>
              <div className="top-0 flex">
                <p>Already register?</p>
                <a className="text-gray-400 cursor-pointer" onClick={() => setIsLogin(false)}>Login here</a>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Register;
