import React, { useState } from "react";
import "../styles/navbar.css";
import Logo from "./Logo";
import DropDown from "../assets/svg/dropDown.svg";
import { GiHamburgerMenu } from "react-icons/gi";
import { GrClose } from "react-icons/gr";
import Button from "./toggleButton";
import ToggleButton from "./toggleButton";

const Menu = [
  {
    href: "/",
    name: "Home",
  },
  {
    href: "/",
    name: "Product",
  },
  {
    href: "/",
    name: "About",
  },
  
];
const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);

  const toggleOpen = () => {
    setOpen(!open);
  };
  const toggleNavbar = () => {
    setMenu(!menu);
  };
  return (
    <div className="navbar md:flex justify-between items-center md:max-w-screen-xl md:mx-auto pt-2 pb-3
    ">
      <div className="hidden md:block ">
        <div className=" flex items-baseline space-x-4 pr-28">
          {Menu.map((x) => (
            <a href={x.href} className="rounded-md text-lg font-serif">
              {x.name}
            </a>
          ))}
        </div>
      </div>
      <Logo  />
      <div className="flex flex-col ">
        <button
          className="items-start px-3 py-2  text-black border-black hover:text-black hover:border-white md:hidden"
          onClick={toggleNavbar}
        >
          {menu ? (
            <GrClose className="h-6 w-6 " />
          ) : (
            <GiHamburgerMenu className="h-6 w-6 " />
          )}
        </button>

        {
            menu &&  <div
            className={` md:hidden h-screen  items-center justify-center py-40 text-center ${
              menu ? "block" : "hidden"
            }`}
          >
            {Menu.map((x) => (
              <div className="flex flex-col ">
                <a href={x.href} className="rounded-md text-lg font-serif mb-4">
                  {x.name}
                </a>
              </div>
            ))}
                <a
                  href="/"
                  className="block px-4 py-2 text-lg font-serif text-black "
                >
                  Profile
                </a>
                <a
                  href="/"
                  className="block px-4 py-2 text-lg font-serif text-black hover:bg-gray-100 "
                >
                  Settings
                </a>
                <a
                  href="/"
                  className="block px-4 py-2 text-lg font-serif text-black hover:bg-gray-100 "
                >
                  Sign out
                </a>
                <button className="btn mt-6">Login</button>
          </div>
        }

       
      </div>

      <div className="gap-3 hidden md:flex">
        <ToggleButton />
        <div onClick={toggleOpen}>
          <DropDown className="dropdown h-9 w-9 border rounded-full border-black" />
          {open && (
            <div className="origin-top-left absolute z-10 mt-2 w-36 rounded-md shadow-lg py-1 bg-black  ring-1 ring-black ring-opacity-5 focus:outline-none">
              <a
                href="/"
                className="block px-4 py-2 text-sm text-white "
              >
                Profile
              </a>
              <a
                href="/"
                className="block px-4 py-2 text-sm text-white"
              >
                Settings
              </a>
              <a
                href="/"
                className="block px-4 py-2 text-sm text-white"
              >
                Sign out
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Navbar;
