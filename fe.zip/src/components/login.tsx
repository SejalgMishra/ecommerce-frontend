import { Form, Formik } from "formik";
import React, { useEffect } from "react";
import abc from "../assets/image/shoes.jpg";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../redux";
import { authenticate } from "../redux/auth/authAction";

interface MyFormValues {
  email: string;
  password: string;
}

interface props {
  setIsLogin: (value: boolean) => void;
  setOpen: (value: boolean) => void;

}
const Login = ({ setIsLogin , setOpen}: props) => {
  const initialValues: MyFormValues = { email: "", password: "" };
  
  
  

  return (
    <div>
      <Formik
        initialValues={initialValues}
        validate={(initialValues) => {
          const errors: Partial<MyFormValues> = {};

          if (!initialValues.email) {
            errors.email = "Email is required";
          }

          if (!initialValues.password) {
            errors.password = "Password is required";
          }

          return errors;
        }}
      >
        {({ values, handleChange, handleSubmit, errors }) => (
          <Form
            onSubmit={handleSubmit}
            onChange={handleChange}
            className="max-w-screen-lg  mx-auto #d4d4d8  mt-36  h-[70%] text-white flex "
          >
            <img src={abc} className="w-[50%] rounded-l-xl" />
            <div className="flex flex-col items-center  w-[50%] justify-center px-3 bg-black opacity-90 rounded-r-xl">
              <h1 className="text-2xl font-bold mb-4">Login Page</h1>

              <input
                name="email"
                value={values.email}
                onChange={handleChange}
                placeholder="Your Email"
                className="p-2 border-2 w-full  rounded-lg mb-2"
                type="email"
              />
              <input
                name="password"
                value={values.password}
                onChange={handleChange}
                placeholder="Your password"
                className="p-2 border-2 w-full rounded-lg mb-2"
                type="password"
              />
              <button
                type="submit"
                className="p-2 border-2 w-full border-gray-700  rounded-lg text-white"
                onClick={() => setOpen(false)}
              >
                Submit
              </button>
              <div className="top-0 flex">
                <p>not register?</p>
                <a
                  className="text-gray-400 cursor-pointer"
                  onClick={() => setIsLogin(true)}
                >
                  Register here
                </a>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Login;
