export const TYPES = {
    LOAD_PRODUCT_REQUEST : "LOAD_PRODUCT_REQUEST",
    LOAD_PRODUCT_SUCCESS:"LOAD_PRODUCT_SUCCESS",
    LOAD_PRODUCT_FAIL: "LOAD_PRODUCT_FAIL"
  };
  
  
  
  export const getProduct = (Data : any) => {
    return {
      type: "LOAD_PRODUCT_SUCCESS",
      payload : Data,
    };
  };
  
  export const getAllProduct = (Data : any) => {
    return {
      type: "LOAD_PRODUCT_SUCCESS",
      payload : Data,
    };
  };
  
  