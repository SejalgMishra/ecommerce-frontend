import React from 'react'
import { useSelector } from 'react-redux';

const CheckOut = () => {
    const userAddress = useSelector((state) => state.auth);
    console.log(userAddress);

    const cartItem = useSelector((state) => state.cart.cart);
    console.log(cartItem);
    

    const subtotal = cartItem.reduce((total, item) => {
        return total + item.price * item.quantity;
      }, 0);

  return (
    <div>
        <h1 className="text-center text-3xl font-font">Check Out</h1>
        <div className='border justify-center items-center  flex flex-col py-5 my-4 max-w-screen-md mx-auto'>
         <h2 className='text-2xl font-[cursive]'>Address for Delivary</h2>
         <div className='flex text-lg font-[cursive]'>
         <p>{userAddress.data[0].address} ,</p>
         <p>{userAddress.data[0].city} ,</p>
         <p>{userAddress.data[0].country} , </p>
         <p>{userAddress.data[0].zipCode} </p>
         </div>
        </div>
        <div className='flex flex-col py-5 my-4 max-w-screen-md mx-auto'>
        {cartItem.map((product) => (
              <div
                key={product.productId}
                className="flex gap-4 border p-2 drop-shadow-lg mb-2"
              >
                <img
                  src={product.productimage}
                  alt={product.name}
                  className="aspect-auto h-[150px] w-[450px] object-cover"
                />
                <div className="flex justify-between w-full">
                  <div>
                    <h2 className="font-sans text-xl mb-1">{product.name}</h2>
                    <h3 className="font-font mb-1">productCategory</h3>
                    <div className="flex gap-2">
                      <p className="font-base">
                      {new Intl.NumberFormat("en-IN", {
                            currency: "INR",
                            style: "currency",
                          }).format(product.price  )}
                      </p>
                    </div>
                   
                  </div>
                </div>
            
              </div>
              
            ))}
        </div>
        <button className="btn w-full my-3 rounded-lg hover:bg-black ">
            <p className=" font-semibold text-lg">
              Total :{" "}
              {new Intl.NumberFormat("en-IN", {
                currency: "INR",
                style: "currency",
              }).format(subtotal.toFixed(2))}
            </p>
            <p>
               Place Order
            </p>
          </button>
    </div>
  )
}

export default CheckOut