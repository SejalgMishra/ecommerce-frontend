import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { getDataAPI } from '../utilis/fetchDataApi';
import { getAllProduct, getProduct } from '../redux/product/productAction';
import { useQuery } from 'react-query'

const AllProduct = () => {
 const dispatch = useDispatch();

 const products = useSelector((state) => state.product.products);
 console.log(products);
 console.log(useSelector((state) => state));

 const { error } = useQuery(["get_all_products"], () => {
   const token: any = localStorage.getItem("token");
   getDataAPI("user/product", token).then((res) => {
     dispatch(getAllProduct(res));
   });
   console.log(error);
 });

 return (
   <div className="flex-wrap">
     <div className="flex flex-row justify-between flex-wrap h-[399px] md:h-auto overflow-hidden">
       {products.map((product) => (
         <div key={product.id} className="flex flex-col ">
           <img
             src={product.productimage}
             alt={product.name}
             className="aspect-auto   h-[315px] w-[315px] object-cover"
           />
           <h2 className="font-sans text-xl mb-1">{product.name}</h2>
           <h3 className="font-font mb-1">productCategory</h3>
           <div className="flex gap-2">
             <p className="font-base">$ {product.price} USD</p>
             <p className="line-through opacity-70">{product.price}</p>
           </div>
           <button className="btn-white mb-2">Add to cart</button>
         </div>
       ))}
     </div>
     
   </div>
 );
}

export default AllProduct