import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { persistor, store } from "./redux/store.ts";
import { QueryClient, QueryClientProvider } from "react-query";
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from "react-router-dom";
import MainLayout from "./layouts/MainLayout.tsx";
import MainPage from "./pages/MainPage.tsx";
import ProductPage from "./pages/ProductPage.tsx";

const queryClient = new QueryClient();

const router = createBrowserRouter(
  createRoutesFromElements(
    <>
  <Route path="/" element={<MainLayout />}>
        <Route index element={<MainPage />} />
        <Route path="/productPage" element={<ProductPage />} />
        {/* <Route path="/cart" element={<CartPage />} />
        <Route path="/shippingForm" element={<ShippingForm />} />
  
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/myorder" element={<Myorder />} />
        <Route path="/orderSummery/:id" ex element={<OrderSummery />} /> */}
      </Route>
    </>
  )
)

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <QueryClientProvider client={queryClient}>
        {/* <React.StrictMode> */}
        <RouterProvider router={router} />
      </QueryClientProvider>
      {/* </React.StrictMode> */}
    </PersistGate>
  </Provider>
);
